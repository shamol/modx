--------------------
Extra: Ace
--------------------
Version: 1.4.1
Created: May 21th, 2013
Since: March 29th, 2012
Author: Danil Kostin <danya.postfactum@gmail.com>
License: GNU GPLv2 (or later at your option)

Integrates Ace Code Editor into MODx Revolution.

Press Ctrl+Alt+H to see all available shortcuts.